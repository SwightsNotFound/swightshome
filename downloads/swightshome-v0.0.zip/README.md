# homelab
This has since been simple combined with [swightshome](https://swightshome.xyz/Services), however this can still (for now) by accessed using [homelab.swightshome.xyz](https://homelab.swightshome.xyz/).
