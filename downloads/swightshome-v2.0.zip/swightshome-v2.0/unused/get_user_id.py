import requests

def get_user_id(username):
    query = '''
    query ($username: String) {
        User(name: $username) {
            id
        }
    }
    '''
    variables = {
        'username': username
    }
    url = 'https://graphql.anilist.co'
    response = requests.post(url, json={'query': query, 'variables': variables})
    return response.json()

username = "Swight"  # Replace with your AniList username
user_data = get_user_id(username)
user_id = user_data['data']['User']['id']
print(f"Your AniList user ID is: {user_id}")
